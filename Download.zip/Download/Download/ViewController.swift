//
//  ViewController.swift
//  Download
//
//  Created by Rp on 22/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func getDocumentDirectoryPath()-> String{
        
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        print(documentDirectory)
        
        return documentDirectory
        
    }
    
    @IBAction func clickOnDownload(){
        
        
            
            let data = NSData.init(contentsOf: URL.init(string: "http://publications.gbdirect.co.uk/c_book/thecbook.pdf")!)
            
            print(data)
        
        do{
        
            let strPath = self.getDocumentDirectoryPath() + "/demo.pdf"
            
          let success = try data?.write(toFile: strPath, atomically: true)
            
        }catch{
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

